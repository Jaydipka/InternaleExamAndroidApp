package com.example.empinfo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {
    Db obj = new Db(this, "emp_DB", null, 1);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        getData();
    }


    private void getData() {
        StringBuffer buffer = new StringBuffer();
        AlertDialog.Builder builder = new AlertDialog.Builder(ShowActivity.this);
        Cursor cursor = obj.fetchAllData();
        while (cursor.moveToNext()) {
            buffer.append("empId :" + cursor.getString(0) + "\n");
            buffer.append("empName :" + cursor.getString(1) + "\n");
            buffer.append("empDesignation :" + cursor.getString(2) + "\n");
            buffer.append("empPhone :" + cursor.getString(3) + "\n");
            buffer.append("empEmail :" + cursor.getString(4) + "\n");
            buffer.append("\n");
        }

        builder.setCancelable(true);
        builder.setTitle("Employee Records");
        builder.setMessage(buffer.toString());
        builder.show();

    }
}