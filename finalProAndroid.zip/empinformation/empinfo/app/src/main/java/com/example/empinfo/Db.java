package com.example.empinfo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Db extends SQLiteOpenHelper {
    public Db(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "emp_DB", null, 1);
    }

    public void addData(String name, String Designation, String Phone, String Email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("empName", name);
        cv.put("empDesignation", Designation);
        cv.put("empPhone",Phone);
        cv.put("empEmail",Email);
        db.insert("emp", null, cv);
        db.close();
    }

    public Cursor fetchAllData() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from emp", null, null);
        return cursor;
    }
    public  Cursor searchEmp(String empName){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from emp where empName=?",new String[]{empName});
        return cursor;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table emp(empId integer primary key autoincrement, empName text,empDesignation text,empPhone text,empEmail text )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS emp");
        onCreate(sqLiteDatabase);
    }
}

