package com.example.empinfo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {
    EditText id, name, phone, email;
    AutoCompleteTextView designation;
    Button save;
    Db obj = new Db(this, "emp_DB", null,1);
    String[] arr = { "Manager", "Executive","Clerk",
            "Chief- Executive", "Senior-Clerk"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        id=findViewById(R.id.empIdTxt);
        name=findViewById(R.id.empNameTxt);
        designation=findViewById(R.id.empDesingnationTxt);
        phone=findViewById(R.id.empPhoneTxt);
        email=findViewById(R.id.empEmailTxt);
        save=findViewById(R.id.saveBtn);

        designation=findViewById(R.id.empDesingnationTxt);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item, arr);

        designation.setThreshold(2);
        designation.setAdapter(adapter);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.addData(
                        name.getText().toString(),
                        designation.getText().toString(),
                        phone.getText().toString(),
                        email.getText().toString()

                        );
                Toast.makeText(InsertActivity.this, "Record Inserted..", Toast.LENGTH_LONG).show();
            }

        });
    }
}